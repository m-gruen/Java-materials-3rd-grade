package stock;

public class HiFoStockList extends StockListImpl {
    private Node head;
    private Node tail;

    public HiFoStockList() {
        head = null;
        tail = null;
    }

    @Override
    public void store(ValuedStockMovement valuedStockMovement) {
        // We need to have a sorted list to implement HiFo.
        // When a new stock movement is stored, we need to insert it in the right place.
        // The list is sorted by pricePerUnit and the most expensive stock is at the head.

        var newNode = new Node(valuedStockMovement.clone());

        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            if (valuedStockMovement.pricePerUnit > head.valuedStockMovement.pricePerUnit) {
                newNode.next = head;
                head = newNode;
            } else {
                var current = head;
                while (current.next != null && current.next.valuedStockMovement.pricePerUnit >= valuedStockMovement.pricePerUnit) {
                    current = current.next;
                }

                newNode.next = current.next;
                current.next = newNode;

                if (newNode.next == null) {
                    tail = newNode;
                }
            }

        }

        ingoings.put(valuedStockMovement.clone());
    }

    @Override
    public void remove(StockMovement stockMovement) {
        if (head == null) { return; } // empty list

        var outgoing = new ValuedStockMovement(
                stockMovement.date.clone(),
                0,
                head.valuedStockMovement.pricePerUnit);

        if (head.valuedStockMovement.quantity <= stockMovement.quantity) {
            outgoing.quantity = head.valuedStockMovement.quantity;
            outgoings.put(outgoing);

            var newStockMovement = new StockMovement(
                    stockMovement.date.clone(),
                    stockMovement.quantity - head.valuedStockMovement.quantity);

            head = head.next;
            remove(newStockMovement);
        } else {
            outgoing.quantity = stockMovement.quantity;
            outgoings.put(outgoing);
            head.valuedStockMovement.quantity -= stockMovement.quantity;
        }

    }

    @Override
    public String getStockStatus() {
        var sb = new StringBuilder();

        for (var current = head; current != null; current = current.next) {
            sb.append(current.valuedStockMovement.toString());
            if (current.next != null) { sb.append("\n"); }
        }

        return sb.toString();
    }

    private class Node {
        ValuedStockMovement valuedStockMovement;
        Node next;

        Node(ValuedStockMovement valuedStockMovement) {
            this.valuedStockMovement = valuedStockMovement;
            this.next = null;
        }
    }
}
